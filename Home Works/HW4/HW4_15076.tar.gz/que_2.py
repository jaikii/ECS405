#Author: Jai Kumar Roll No.: 15076

from matplotlib.pylab import *
from math import *
import cmath
import numpy as np
import random
import glob

## P-value calculation
def P(S_):
	FT=abs(np.fft.fft(S_))
	t11=FT[(len(FT)/3)+1]*1.0/mean(FT)						#P value
	return t11
path = 'DNA/*.fna'   
files=glob.glob(path)
for file in files: 											#will read all the files from DNA folder
	F=open(file,'r')
	A=[]
	for i in F:
		l=i.split()
		A+=l
	F.close()
	B=[]
	for i in range(len(A)):
		B+=A[i]
	print len(B)
	seq=[]
	for i in B:
		if i=='G':
			seq.append(1)
		else:
			seq.append(0)

	##Reading .ptt file
	F=open("%s.gff3"%file[:-4],'r')
	coding=[]
	for i in F:
		k=i.split()
		if len(k)>=3:
			if k[2]=='gene':
				coding.append([int(k[3]),int(k[4])])
	F.close()
	y_coding=[]
	y_non_coding=[]
	for i in range(0,len(coding)-1):
		S_coding=seq[coding[i][0]-1:coding[i][1]-1]
		S_non_coding=seq[coding[i][1]:coding[i+1][0]-1]
		if len(S_non_coding)>=50:								#least length for non_coding region
			y_non_coding.append(P(S_non_coding))
		y_coding.append(P(S_coding))
	print mean(y_coding),mean(y_non_coding)
	xlabel("gene Number")
	ylabel("P-Value")
	scatter(range(len(y_coding)),y_coding,color='red',label='coding')
	scatter(range(len(y_non_coding)),y_non_coding,color='blue',label='non-coding')
	legend()
	savefig("%s_2_ans.pdf"%file)
	show()
